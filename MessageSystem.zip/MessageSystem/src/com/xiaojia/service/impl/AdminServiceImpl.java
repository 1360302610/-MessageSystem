package com.xiaojia.service.impl;

import com.xiaojia.bean.Admin;
import com.xiaojia.dao.AdminDao;
import com.xiaojia.dao.impl.AdminDaoImpl;
import com.xiaojia.service.AdminService;

public class AdminServiceImpl implements AdminService {
	private AdminDao ad=new AdminDaoImpl();
	@Override
	public Admin login(String username, String password) {
		return ad.login(username,password);
	}

}
