package com.xiaojia.bean;

import java.util.List;

public class Message {
	/**
	 * id INT  PRIMARY KEY AUTO_INCREMENT,
	NAME VARCHAR(20),
	title VARCHAR(100),
	content TEXT,
	TIME VARCHAR(20),
	replynum INT

	 */
	private int id;
	private String name;
	private String title;
	private String content;
	private String time;
	private int replynum;
	
	private List<ReplyMsg> replyMsg;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public int getReplynum() {
		return replynum;
	}

	public void setReplynum(int replynum) {
		this.replynum = replynum;
	}

	public List<ReplyMsg> getReplyMsg() {
		return replyMsg;
	}

	public void setReplyMsg(List<ReplyMsg> replyMsg) {
		this.replyMsg = replyMsg;
	}
	
	
	
	
}
