package com.xiaojia.bean;

import java.util.List;


public class PageBean {

	
	private int totallPage;
	private List<Message> messages;
	private int currentPage;
	private int pageSize;
	private int count;
	public int getTotallPage() {
		return totallPage;
	}
	public void setTotallPage(int totallPage) {
		this.totallPage = totallPage;
	}
	public List<Message> getMessages() {
		return messages;
	}
	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	
	
}
