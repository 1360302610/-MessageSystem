package com.xiaojia.service.impl;

import java.util.List;

import com.xiaojia.bean.Message;
import com.xiaojia.bean.PageBean;
import com.xiaojia.bean.ReplyMsg;
import com.xiaojia.dao.MessageDao;
import com.xiaojia.dao.impl.MessageDaoImpl;
import com.xiaojia.service.MessageService;
/**
 * 业务逻辑层接口实现类
 * @author wu
 *
 */
public class MessageServiceImpl implements MessageService {
	private MessageDao md=new MessageDaoImpl();
	@Override
	public void addMessage(Message msg) {
		md.addMessage(msg);
	}
	@Override
	public List<Message> findAllMessage() {
		return md.findAllMessage();
	}
	@Override
	public Message findMessageById(String id) {
		return md.findMessageById(id);
	}
	@Override
	public List<ReplyMsg> findAllReplyByMessageId(String id) {
		return md.findAllReplyByMessageId(id);
	}
	@Override
	public void addReplyMessage(String rtime, String rcontent, String mid,
			String rname) {
		md.addReplyMessage(rtime,rcontent,mid,rname);
		md.updateReplyNum(mid);
	}
	@Override
	public PageBean findMessagePage(int currentPage, int pageSize,String search) {
		PageBean pb=new PageBean();
		int count=md.count(search);//获取满足条件的留言的总记录数
		//计算总页数
		int totallPage=(int) Math.ceil(count*1.0/pageSize);
		List<Message> messages=md.findMessagePage(currentPage,pageSize,search);
		
		//将数据封装到Pagebean
		pb.setCount(count);
		pb.setTotallPage(totallPage);
		pb.setCurrentPage(currentPage);
		pb.setPageSize(pageSize);
		pb.setMessages(messages);
		return pb;
	}
	@Override
	public void deleteById(String id) {
		md.deleteReplyById(id);
		md.deleteMessageById(id);
		
	}

}
