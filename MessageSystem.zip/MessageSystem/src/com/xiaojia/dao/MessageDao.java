package com.xiaojia.dao;

import java.util.List;

import com.xiaojia.bean.Message;
import com.xiaojia.bean.ReplyMsg;

/**
 * 持久层接口
 * @author wu
 *
 */
public interface MessageDao {

	/**
	 * 添加一条留言信息
	 * @param msg
	 */
	void addMessage(Message msg);

	/**
	 * 返回所有的留言
	 * @return
	 */
	List<Message> findAllMessage();

	/**
	 * 通过id查出某条留言
	 * @param id
	 * @return
	 */
	Message findMessageById(String id);

	/**
	 * 查出该留言的所有回复
	 * @param id
	 * @return
	 */
	List<ReplyMsg> findAllReplyByMessageId(String id);

	/**
	 * 回复留言
	 * @param rtime
	 * @param rcontent
	 * @param mid
	 * @param rname
	 */
	void addReplyMessage(String rtime, String rcontent, String mid, String rname);

	/**
	 * 更新回复数量
	 * @param mid
	 */
	void updateReplyNum(String mid);

	/**
	 * 获取留言的总记录数
	 * @return
	 */
	int count(String search);

	/**
	 * 分页查询
	 * @param currentPage
	 * @param pageSize
	 * @return
	 */
	List<Message> findMessagePage(int currentPage, int pageSize,String search);

	/**
	 * 删除回复留言
	 * @param id
	 */
	void deleteReplyById(String id);

	/**
	 * 根据id删除留言
	 * @param id
	 */
	void deleteMessageById(String id);

}
