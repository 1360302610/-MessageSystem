package com.xiaojia.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xiaojia.bean.Message;
import com.xiaojia.bean.ReplyMsg;
import com.xiaojia.service.MessageService;
import com.xiaojia.service.impl.MessageServiceImpl;

public class FindMessageDetail extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		MessageService ms=new MessageServiceImpl();
		Message _message=ms.findMessageById(id);
		//调用业务逻辑
		List<ReplyMsg> replyMsgs=ms.findAllReplyByMessageId(id);
		_message.setReplyMsg(replyMsgs);
		
		request.setAttribute("_message", _message);
		request.getRequestDispatcher("/details.jsp").forward(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
