package com.xiaojia.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xiaojia.bean.Message;
import com.xiaojia.service.MessageService;
import com.xiaojia.service.impl.MessageServiceImpl;
import com.xiaojia.utils.DateUtils;

public class AddMessageServlet extends HttpServlet {

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String title = request.getParameter("title");
		String name=request.getParameter("name");
		String content=request.getParameter("content");
		String admin = request.getParameter("admin");
		String time = DateUtils.getCurrentTime();
		
		Message msg=new Message();
		msg.setTitle(title);
		msg.setName(name);
		msg.setContent(content);
		msg.setTime(time);
		msg.setReplynum(0);
		
		//调用业务逻辑
		MessageService ms=new MessageServiceImpl();
		ms.addMessage(msg);
		if(admin==null | "".equals(admin)){
			response.sendRedirect(request.getContextPath()+"/findAllMessageServlet");			
		}else{
			response.sendRedirect(request.getContextPath()+"/findAllMessageServlet?admin="+1);	
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
