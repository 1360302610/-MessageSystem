package com.xiaojia.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xiaojia.bean.ReplyMsg;
import com.xiaojia.service.MessageService;
import com.xiaojia.service.impl.MessageServiceImpl;
import com.xiaojia.utils.DateUtils;

public class AddReplyMessageServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String anonymous = request.getParameter("anonymous");
		String rname="匿名";
		if(anonymous==null){
			 rname = request.getParameter("rname");
		}
		String rcontent = request.getParameter("rcontent");
		String mid = request.getParameter("mid");
		String rtime=DateUtils.getCurrentTime();
		
		MessageService ms=new MessageServiceImpl();
		ms.addReplyMessage(rtime,rcontent,mid,rname);
		
		response.sendRedirect(request.getContextPath()+"/findMessageDetail?id="+mid);
		//request.getRequestDispatcher(").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
