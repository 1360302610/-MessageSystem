create database messagesystem;
use messagesystem;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aname` varchar(20) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8



CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `content` text,
  `time` varchar(20) DEFAULT NULL,
  `replynum` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8



CREATE TABLE `replymsg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rtime` varchar(20) DEFAULT NULL,
  `rcontent` text,
  `mid` int(11) DEFAULT NULL,
  `rname` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `replymsg_ibfk_1` (`mid`),
  CONSTRAINT `replymsg_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `message` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8
