package com.xiaojia.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xiaojia.bean.Admin;
import com.xiaojia.service.AdminService;
import com.xiaojia.service.impl.AdminServiceImpl;

public class LoginServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String validateCode = request.getParameter("validateCode");
		String  sessionCode = (String) request.getSession().getAttribute("sessionCode");
		if(!sessionCode.equals(validateCode)){
			request.setAttribute("codeError","验证码错误");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}else{
			
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			AdminService as=new AdminServiceImpl();
			Admin admin=as.login(username,password);
			if(admin==null){
				request.setAttribute("nameOrpwdError","用户名或密码不匹配");
				request.getRequestDispatcher("/login.jsp").forward(request, response);
			}else{
				request.getSession().setAttribute("admin",admin);
				response.sendRedirect(request.getContextPath()+"/findAllMessageServlet?admin="+Math.random());
			}
		}
		
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
