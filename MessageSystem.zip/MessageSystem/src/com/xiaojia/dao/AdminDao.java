package com.xiaojia.dao;

import com.xiaojia.bean.Admin;

public interface AdminDao {

	/**\
	 *管理员登录
	 * @param username
	 * @param password
	 * @return
	 */
	Admin login(String username, String password);

}
