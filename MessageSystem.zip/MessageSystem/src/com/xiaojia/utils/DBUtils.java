package com.xiaojia.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 * ���ݿ⹤����
 * @author wu
 *
 */
public class DBUtils {
	private static String url="jdbc:mysql://localhost:3306/messageSystem";
	private static String user="root";//mysql���ݿ���˺�
	private static String password="123456";
	
	static{
		try {
			Class.forName("com.mysql.jdbc.Driver"); //��������
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	/**
	 * �õ�һ������
	 * @return
	 */
	public static Connection getConnection(){
		try {
			return DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/***
	 * �ͷ���Դ
	 * @param conn
	 * @param ps
	 * @param rs
	 */
	public static void release(Connection conn,PreparedStatement ps,ResultSet rs){
		if(conn!=null){
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		conn=null;
		if(ps!=null){
			try {
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		ps=null;
		if(rs!=null){
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		rs=null;
	}
}
