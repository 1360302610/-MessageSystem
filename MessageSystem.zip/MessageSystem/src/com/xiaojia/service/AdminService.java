package com.xiaojia.service;

import com.xiaojia.bean.Admin;

public interface AdminService {

	/**
	 * 登录
	 * @param username
	 * @param password
	 * @return
	 */
	Admin login(String username, String password);

}
