package com.xiaojia.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import com.xiaojia.bean.Admin;
import com.xiaojia.dao.AdminDao;
import com.xiaojia.utils.DBUtils;
import com.xiaojia.utils.MD5Utils;

public class AdminDaoImpl implements AdminDao {

	@Override
	public Admin login(String username, String password) {
		Connection conn=DBUtils.getConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try{
			ps=conn.prepareStatement("select * from admin where aname=? and password=?");
			ps.setString(1, username);
			System.out.println("md5密码:"+MD5Utils.md5(password));
			ps.setString(2,MD5Utils.md5(password));
			 rs = ps.executeQuery();
			 while(rs.next()){
				Admin admin=new Admin();
				admin.setId(rs.getInt("id"));
				admin.setAname(rs.getString("aname"));
				admin.setPassword(rs.getString("password"));
				return admin;
			 }
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBUtils.release(conn, ps, rs);
		}
		return null;
	}

}
