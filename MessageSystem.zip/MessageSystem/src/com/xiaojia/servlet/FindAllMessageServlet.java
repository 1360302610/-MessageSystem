package com.xiaojia.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xiaojia.bean.Message;
import com.xiaojia.bean.PageBean;
import com.xiaojia.service.MessageService;
import com.xiaojia.service.impl.MessageServiceImpl;

public class FindAllMessageServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
//		MessageService ms=new MessageServiceImpl();
//		List<Message> messages=ms.findAllMessage();
//		request.setAttribute("messages",messages);
//		request.getRequestDispatcher("/index2.jsp").forward(request, response);
		
		String admin = request.getParameter("admin");
		//搜索关键字
		String search=request.getParameter("search");
		int currentPage=1; //当前页  默认第一页
		int pageSize=8;    //每页显示的图书数量
		String currPage=request.getParameter("currentPage");//从上一页或下一页得到数据
		if(currPage!=null){
			currentPage=Integer.parseInt(currPage);
		}
		//调用业务逻辑
		MessageService ms=new MessageServiceImpl();
		PageBean pb=null;
		if(search==null){
			pb=ms.findMessagePage(currentPage,pageSize,"");
		}else{
			pb=ms.findMessagePage(currentPage,pageSize,search);
		}
		request.setAttribute("pb", pb);
		if(admin==null || "".equals(admin)){
			request.getRequestDispatcher("/index2.jsp").forward(request, response);
		}else{
			request.getRequestDispatcher("/home.jsp").forward(request, response);
		}
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
